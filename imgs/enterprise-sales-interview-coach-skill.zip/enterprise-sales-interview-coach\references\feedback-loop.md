# 匿名面试结果反馈闭环

## 目的

用匿名、结构化结果发现技能可能存在的评分偏差和准备盲区。反馈用于提出和验证改进假设，不用于承诺录用概率或评价个人价值。

```mermaid
flowchart LR
    A["用户自愿反馈结果"] --> B["取得整理同意"]
    B --> C["删除身份与敏感信息"]
    C --> D["标准化阶段和原因标签"]
    D --> E["聚合分析"]
    E --> F["提出改进假设"]
    F --> G["匿名评测集回归测试"]
    G --> H{"质量和公平性改善？"}
    H -- "是" --> I["更新版本与说明"]
    H -- "否" --> J["撤销假设或继续收集"]
    I --> A
    J --> E
```

## 同意与数据最小化

在整理前明确询问用户是否愿意生成匿名反馈记录。默认不保存、不上传、不提交 GitHub。

禁止记录：

- 姓名、电话、邮箱、账号和精确地址；
- 学校全名、可唯一识别的专业/班级组合；
- 原始简历、完整 JD、聊天原文或录音；
- 具体客户名、保密项目、未公开业绩和面试官身份；
- 性别、年龄、民族、婚育、健康等与质量改进无关的敏感属性。

可以记录经过泛化的信息：

- 行业、岗位族、校招/早期职业模式；
- 公司类型和规模区间，不记录公司名；
- 面试阶段、结果和时间区间；
- 失败/通过原因标签及其证据级别；
- 技能版本、初始匹配分区和材料覆盖率；
- 用户认为最有帮助与最欠缺的模块。

## 标准反馈记录

```yaml
feedback_id: random-id
skill_version: "x.y.z"
consent: true
created_month: "YYYY-MM"
candidate_mode: campus
industry: ict
role_family: enterprise-account-manager
company_segment: large-enterprise
initial_score_band: "60-69"
evidence_coverage_band: "70-79"
furthest_stage: hiring-manager
outcome: rejected
reason_labels:
  - product-knowledge
reason_evidence: recruiter-explicit
helpful_modules:
  - resume-rewrite
missing_modules:
  - industry-case
free_text_redacted: "不超过 100 字的匿名摘要"
```

## 阶段标签

- `application`
- `online-assessment`
- `recruiter-screen`
- `group-interview`
- `hiring-manager`
- `case-presentation`
- `final`
- `offer`
- `unknown`

## 原因标签

- `resume-evidence`
- `motivation-role-fit`
- `communication-structure`
- `commercial-judgment`
- `product-knowledge`
- `industry-knowledge`
- `sales-method`
- `case-performance`
- `language`
- `location-or-availability`
- `experience-gap`
- `headcount-or-process`
- `unknown`

证据级别：

- `recruiter-explicit`：招聘方明确反馈；
- `candidate-reported`：候选人根据现场情况判断；
- `skill-inferred`：技能推断，置信度最低。

## 聚合与更新门槛

不要根据单条反馈修改规则。满足以下条件后再评估：

1. 同一岗位族/行业有足够多的独立匿名样本；
2. 结果不由单一学校、公司或招聘季主导；
3. 明确区分招聘方反馈与候选人推测；
4. 先在冻结的匿名评测集上测试；
5. 检查改动是否提高某组表现却伤害另一组；
6. 记录版本、假设、证据、指标变化和回滚条件。

不设置固定最小样本量来制造统计确定性；根据分层数量、结果差异和不确定性报告决定。样本不足时只报告趋势，不修改核心权重。

## 推荐指标

- 阶段推进率：仅作描述，不解释为技能导致；
- 评分校准：相同分区在不同样本中的阶段分布；
- 材料覆盖率与错误率；
- 事实/推断混淆率；
- 评分者一致性；
- 不同行业和候选人模式下的表现差异；
- 用户对各模块的帮助度评价。

## 输出要求

生成反馈时先给用户预览匿名记录，让用户删除或修改。只有用户明确要求保存时才写文件；只有用户明确要求发布时才进入 GitHub 工作流。
